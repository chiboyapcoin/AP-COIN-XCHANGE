import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { Services } from "./components/Services";
import { RatesCalculator } from "./components/RatesCalculator";
import { HowItWorks } from "./components/HowItWorks";
import { ReferralProgram } from "./components/ReferralProgram";
import { Blog } from "./components/Blog";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";
import { LiveChat } from "./components/LiveChat";

export default function App() {
  const [activeSection, setActiveSection] = useState("home");

  useEffect(() => {
    const handleScroll = () => {
      const sections = ["home", "services", "calculator", "how-it-works", "referral", "blog", "contact"];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Header activeSection={activeSection} />
      
      <main>
        <section id="home">
          <Hero />
        </section>
        
        <section id="services" className="py-20 bg-gray-50">
          <Services />
        </section>
        
        <section id="calculator" className="py-20">
          <RatesCalculator />
        </section>
        
        <section id="how-it-works" className="py-20 bg-gray-50">
          <HowItWorks />
        </section>
        
        <section id="referral" className="py-20">
          <ReferralProgram />
        </section>
        
        <section id="blog" className="py-20 bg-gray-50">
          <Blog />
        </section>
        
        <section id="contact" className="py-20">
          <Contact />
        </section>
      </main>
      
      <Footer />
      <LiveChat />
      <Toaster />
    </div>
  );
}
