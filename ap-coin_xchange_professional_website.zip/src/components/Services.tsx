export function Services() {
  const services = [
    {
      name: "Alipay",
      icon: "💳",
      description: "Secure payments with China's leading digital wallet",
      color: "bg-blue-100 text-blue-700"
    },
    {
      name: "WeChat Pay",
      icon: "💬",
      description: "Fast transfers through WeChat's payment system",
      color: "bg-green-100 text-green-700"
    },
    {
      name: "China AZA",
      icon: "🏦",
      description: "Direct bank transfers within China",
      color: "bg-red-100 text-red-700"
    },
    {
      name: "Western Union",
      icon: "🌍",
      description: "Global money transfer service",
      color: "bg-yellow-100 text-yellow-700"
    },
    {
      name: "Cash App",
      icon: "💰",
      description: "Quick peer-to-peer payments",
      color: "bg-purple-100 text-purple-700"
    },
    {
      name: "PayPal",
      icon: "🔵",
      description: "Worldwide online payment platform",
      color: "bg-blue-100 text-blue-700"
    },
    {
      name: "Zelle",
      icon: "⚡",
      description: "Instant bank-to-bank transfers",
      color: "bg-indigo-100 text-indigo-700"
    },
    {
      name: "Venmo",
      icon: "📱",
      description: "Social payment app for easy transfers",
      color: "bg-cyan-100 text-cyan-700"
    },
    {
      name: "Bitcoin",
      icon: "₿",
      description: "Leading cryptocurrency exchange",
      color: "bg-orange-100 text-orange-700"
    },
    {
      name: "USDT",
      icon: "💎",
      description: "Stable cryptocurrency trading",
      color: "bg-green-100 text-green-700"
    },
    {
      name: "Ethereum",
      icon: "Ξ",
      description: "Smart contract cryptocurrency",
      color: "bg-gray-100 text-gray-700"
    },
    {
      name: "Gift Cards",
      icon: "🎁",
      description: "Exchange various gift cards for cash",
      color: "bg-pink-100 text-pink-700"
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold text-gray-900 mb-4">
          Supported Payment Platforms
        </h2>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          We support a wide range of payment methods and cryptocurrencies to make your exchanges seamless and convenient.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {services.map((service, index) => (
          <div
            key={service.name}
            className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100 hover:border-blue-200 group"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <div className={`w-16 h-16 rounded-lg ${service.color} flex items-center justify-center text-2xl mb-4 group-hover:scale-110 transition-transform duration-300`}>
              {service.icon}
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              {service.name}
            </h3>
            <p className="text-gray-600 text-sm">
              {service.description}
            </p>
          </div>
        ))}
      </div>

      <div className="text-center mt-12">
        <button
          onClick={() => window.open("https://wa.me/message/SHOYCMWGOS6UD1", "_blank")}
          className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors font-semibold"
        >
          Get Started Today
        </button>
      </div>
    </div>
  );
}
