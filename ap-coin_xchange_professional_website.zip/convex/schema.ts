import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  exchangeRates: defineTable({
    fromCurrency: v.string(),
    toCurrency: v.string(),
    rate: v.number(),
    lastUpdated: v.number(),
  }).index("by_currencies", ["fromCurrency", "toCurrency"]),
  
  blogPosts: defineTable({
    title: v.string(),
    content: v.string(),
    excerpt: v.string(),
    author: v.string(),
    publishedAt: v.number(),
    tags: v.array(v.string()),
    featured: v.boolean(),
  }).index("by_published", ["publishedAt"]),
  
  referrals: defineTable({
    referrerUserId: v.optional(v.id("users")),
    refereeEmail: v.string(),
    status: v.string(), // "pending", "completed", "paid"
    bonusAmount: v.number(),
    createdAt: v.number(),
  }).index("by_referrer", ["referrerUserId"]),
  
  transactions: defineTable({
    userId: v.optional(v.id("users")),
    fromCurrency: v.string(),
    toCurrency: v.string(),
    amount: v.number(),
    convertedAmount: v.number(),
    status: v.string(), // "pending", "processing", "completed", "failed"
    whatsappNumber: v.string(),
    createdAt: v.number(),
  }).index("by_user", ["userId"]).index("by_status", ["status"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
