import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

// Sample exchange rates - in production, these would be fetched from external APIs
const defaultRates = [
  { fromCurrency: "USD", toCurrency: "NGN", rate: 1650 },
  { fromCurrency: "EUR", toCurrency: "NGN", rate: 1750 },
  { fromCurrency: "GBP", toCurrency: "NGN", rate: 2000 },
  { fromCurrency: "CNY", toCurrency: "NGN", rate: 230 },
  { fromCurrency: "BTC", toCurrency: "USD", rate: 45000 },
  { fromCurrency: "ETH", toCurrency: "USD", rate: 2800 },
  { fromCurrency: "USDT", toCurrency: "NGN", rate: 1640 },
];

export const getRates = query({
  args: {},
  handler: async (ctx) => {
    const rates = await ctx.db.query("exchangeRates").collect();
    if (rates.length === 0) {
      // Initialize with default rates
      for (const rate of defaultRates) {
        await ctx.db.insert("exchangeRates", {
          ...rate,
          lastUpdated: Date.now(),
        });
      }
      return defaultRates.map(rate => ({ ...rate, lastUpdated: Date.now() }));
    }
    return rates;
  },
});

export const getRate = query({
  args: { fromCurrency: v.string(), toCurrency: v.string() },
  handler: async (ctx, args) => {
    const rate = await ctx.db
      .query("exchangeRates")
      .withIndex("by_currencies", (q) => 
        q.eq("fromCurrency", args.fromCurrency).eq("toCurrency", args.toCurrency)
      )
      .first();
    
    if (!rate) {
      // Try reverse rate
      const reverseRate = await ctx.db
        .query("exchangeRates")
        .withIndex("by_currencies", (q) => 
          q.eq("fromCurrency", args.toCurrency).eq("toCurrency", args.fromCurrency)
        )
        .first();
      
      if (reverseRate) {
        return {
          fromCurrency: args.fromCurrency,
          toCurrency: args.toCurrency,
          rate: 1 / reverseRate.rate,
          lastUpdated: reverseRate.lastUpdated,
        };
      }
    }
    
    return rate;
  },
});

export const calculateExchange = query({
  args: { 
    amount: v.number(), 
    fromCurrency: v.string(), 
    toCurrency: v.string() 
  },
  handler: async (ctx, args) => {
    const rate = await ctx.runQuery("exchangeRates:getRate", {
      fromCurrency: args.fromCurrency,
      toCurrency: args.toCurrency,
    });
    
    if (!rate) {
      return null;
    }
    
    return {
      originalAmount: args.amount,
      convertedAmount: args.amount * rate.rate,
      rate: rate.rate,
      fromCurrency: args.fromCurrency,
      toCurrency: args.toCurrency,
    };
  },
});
