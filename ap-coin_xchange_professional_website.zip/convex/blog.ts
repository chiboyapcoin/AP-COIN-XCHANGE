import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const getPosts = query({
  args: { limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const limit = args.limit || 10;
    return await ctx.db
      .query("blogPosts")
      .withIndex("by_published")
      .order("desc")
      .take(limit);
  },
});

export const getFeaturedPosts = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("blogPosts")
      .filter((q) => q.eq(q.field("featured"), true))
      .order("desc")
      .take(3);
  },
});

export const getPost = query({
  args: { id: v.id("blogPosts") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.id);
  },
});

// Sample blog posts initialization
export const initializeBlogPosts = mutation({
  args: {},
  handler: async (ctx) => {
    const existingPosts = await ctx.db.query("blogPosts").take(1);
    if (existingPosts.length > 0) return;

    const samplePosts = [
      {
        title: "Understanding Cryptocurrency Exchange Rates",
        content: "Cryptocurrency markets are highly volatile, with prices fluctuating based on various factors including market demand, regulatory news, and technological developments. At AP-COIN XCHANGE, we provide real-time rates to ensure you get the best value for your digital assets.",
        excerpt: "Learn how cryptocurrency exchange rates work and how to get the best deals.",
        author: "AP-COIN XCHANGE Team",
        publishedAt: Date.now() - 86400000, // 1 day ago
        tags: ["cryptocurrency", "exchange", "rates"],
        featured: true,
      },
      {
        title: "Secure Digital Payments: Best Practices",
        content: "Security is paramount when dealing with digital payments. Always verify the recipient, use secure networks, and keep your payment credentials private. Our platform implements bank-level security to protect your transactions.",
        excerpt: "Essential security tips for safe digital transactions.",
        author: "Security Team",
        publishedAt: Date.now() - 172800000, // 2 days ago
        tags: ["security", "payments", "tips"],
        featured: true,
      },
      {
        title: "Global Payment Solutions: Bridging Continents",
        content: "With support for multiple payment platforms including Alipay, WeChat Pay, PayPal, and more, we're making international money transfers faster and more accessible than ever before.",
        excerpt: "How we're connecting global payment systems for seamless transfers.",
        author: "Product Team",
        publishedAt: Date.now() - 259200000, // 3 days ago
        tags: ["global", "payments", "international"],
        featured: false,
      },
    ];

    for (const post of samplePosts) {
      await ctx.db.insert("blogPosts", post);
    }
  },
});
